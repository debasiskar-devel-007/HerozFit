#######################################################

 Magic Zoom™
 Drupal 7 module version v2.16.18 [v1.4.20:v4.5.30]
 
 www.magictoolbox.com
 support@magictoolbox.com

 Copyright 2015 Magic Toolbox

#######################################################

INSTALLATION:

1. Unzip the Drupal module.

2. Upload the 'magiczoom' folder to the modules folder of your Drupal website.

3. If you're on a Unix machine, make write access for these file:

./modules/magiczoom/magiczoom.css

You can make write access using this command in the Drupal directory:

chmod 777 ./modules/magiczoom/magiczoom.css

4. Activate and configure the Magic Zoom module in Drupal Administration Panel.

5. Magic Zoom is ready to use!

6. To upgrade your version of Magic Zoom (which removes the "Please upgrade" text), buy Magic Zoom and overwrite the modules/magiczoom/magiczoom.js file file with the new one in your licensed version.

Buy a single license here:

http://www.magictoolbox.com/buy/magiczoom/


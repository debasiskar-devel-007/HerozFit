
      <?php print render($page['content']); ?>
